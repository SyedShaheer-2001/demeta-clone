__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/96c17296338fda20.js",
  "static/chunks/turbopack-4237a21fbb6ccb5e.js"
])
