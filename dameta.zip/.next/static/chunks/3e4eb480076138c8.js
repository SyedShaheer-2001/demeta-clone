__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/96c17296338fda20.js",
  "static/chunks/turbopack-e3a95325f12381b5.js"
])
